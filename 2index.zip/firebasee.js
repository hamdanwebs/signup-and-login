// Import Firebase SDKs
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup ,signOut ,onAuthStateChanged}  from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

// Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyC6Vw3-6DcdZdkskE8IceY-RIO_AM1G1kI",
  authDomain: "fire-base-signup-login-page1-0.firebaseapp.com",
  projectId: "fire-base-signup-login-page1-0",
  storageBucket: "fire-base-signup-login-page1-0.firebasestorage.app",
  messagingSenderId: "5059563449",
  appId: "1:5059563449:web:24d4d85d42a71e669cf068"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);


export{ getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup ,signOut, auth ,onAuthStateChanged};



document.getElementById("createAccountBtn").addEventListener("click", () => {
    const email = document.getElementById("signupEmail").value;
    const password = document.getElementById("signupPassword").value;

    createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
            alert("Account created successfully!");
            console.log(userCredential.user);
             window.location.href = "to-do.html";
        })
        .catch((error) => {
            alert(error.message);
        });
});

document.getElementById("loginBtn").addEventListener("click", () => {
    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    signInWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
    alert("Login successful!");
    console.log(userCredential.user);
    
    // Redirect to index.html
    window.location.href = "to-do.html";  // Opens in the same tab
})
.catch((error) => {
    alert(error.message);
});
});

const googleProvider = new GoogleAuthProvider();
document.getElementById("googleSignInBtn").addEventListener("click", () => {
    signInWithPopup(auth, googleProvider)
        .then((result) => {
            alert("Signed in with Google!");
            console.log(result.user);
            window.location.href = "to-do.html";
        })
        .catch((error) => {
            alert(error.message);
        });
}); 






// signout

onAuthStateChanged(auth, (user) => {
  if (user) {
    // User is signed in, see docs for a list of available properties
    // https://firebase.google.com/docs/reference/js/auth.user
    const uid = user.uid;
    window.location.replace("./2index.html")
    // ...
  } else {
    // User is signed out
    // ...
  }
});


    // Sign out function
   let signBtn = document.getElementById("signOutBtn")
    
    





    
    signBtn.addEventListener("click", () => {

        console.log("Sign out button clicked");
      signOut(auth)
        .then(() => {
          alert("Signed out successfully!");
         window.location.replace ("2index.html"); // Redirect to login page
        })
        .catch((error) => {
          alert("Error signing out: " + error.message);
        });
    });